/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

bool binary(int values[], int low, int high, int value);

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    // TODO: implement a searching algorithm
    return binary(values,0,n - 1,value);
   
}

bool binary(int values[], int low, int high, int value)
{   
    
    if (low > high)
    {
        return false;
    }    
    else
    {
        int mid = (low + high) / 2;
            
        if (values[mid] == value)
        {
            return true;
        }
        else if (values[mid] > value)
        {
            return binary(values,low,mid - 1,value); 
        }
        else
        {
            return binary(values,mid + 1,high,value);
        }
    }
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
    for (int i = 0;i < n - 1;i++)
    {
        for (int j = 0;j < n - 1 - i;j++)
        {
            if (values[j] > values[j + 1])
            {
                int t = values[j];
                values[j] = values[j + 1];
                values[j + 1] = t;
            }
        }
    }
    return;
}